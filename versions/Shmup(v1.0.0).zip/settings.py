# Game constants - settings
from os import path
import pygame

# ---Window settings
WIDTH = 600
HEIGHT = 800
TITLE = "Shmup!"
FPS = 60

# ---Define Colors
WHITE = 255, 255, 255
BLACK = 0, 0, 0
RED = 255, 0, 0
GREEN = 0, 255, 0
BLUE = 0, 0, 255
YELLOW = 255, 255, 0

# ---Directories
img_dir = path.join(path.dirname(__file__), "images")
snd_dir = path.join(path.dirname(__file__), "sounds")

# ---Global variables
clock = pygame.time.Clock()

# ---Load images/sounds

background = pygame.image.load(path.join(img_dir, "black.png"))
background = pygame.transform.scale(background, (WIDTH, HEIGHT))
background_rect = background.get_rect()

player_ship = pygame.image.load(path.join(img_dir, "playerShip2_orange.png"))
meteor_images = []
meteor_list = ['meteorBrown_big1.png', 'meteorBrown_big3.png',
               'meteorBrown_big4.png', 'meteorBrown_med1.png',
               'meteorBrown_med3.png', 'meteorBrown_small1.png',
               'meteorBrown_small2.png', 'meteorBrown_tiny1.png', 'meteorBrown_tiny2.png',
               'meteorGrey_big1.png', 'meteorGrey_big3.png',
               'meteorGrey_big4.png', 'meteorGrey_med1.png',
               'meteorGrey_med2.png', 'meteorGrey_small1.png',
               'meteorGrey_small2.png', 'meteorGrey_tiny1.png',
               'meteorGrey_tiny1.png']

for img in meteor_list:
    meteor_images.append(pygame.image.load(path.join(img_dir, img)))
