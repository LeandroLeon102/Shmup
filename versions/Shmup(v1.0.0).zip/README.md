#Shmup!(v1.0.0)

#### Description of the game:

This is a space shooter game where meteors and enemy ships
and are falling.You need to survive all the time you can and get the best score, but don't worry, you can be helped by some powerups.

######**in this version of the game, only meteors will appear for you to destroy, and only shows your current score*

#How to run the game
1 ) You must have installed python 3.7 or greater on your system(if you don't, visit https://www.python.org/downloads/)

* If you are in Ubuntu/Debian based OS, only type "sudo apt-get install python3" in the comand line and type your password to allow the system install it
* If you are in RedHat/CentOS based OS, only type "sudo yum install python3" in the comand line and type your password to allow the system install it

2 ) Once you have python in your system,you must have installed the Pygame library according to your python version(if you don't visit https://www.pygame.org/download.shtml).

* If you are in Linux based OS, only type "sudo pip3 install python3" in the comand line and type your password to allow the system install it

3 ) once you have Python and Pygame, only run the "main.py" file with Python

#Notice
This is the 1.0.0 game version

###Author: Leandro Leon Soto 
