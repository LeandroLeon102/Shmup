import sys
import time
from sprites import *

def check_new_game():
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game.running = False
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                game.running = False
                pygame.quit()
                sys.exit()
        if event.type == pygame.KEYUP:
            if event.key != pygame.K_ESCAPE:
                game.new_game()
                waiting = False

def draw_lives(lives):
    x = 400
    for i in range(lives):
        img_rect = life_img.get_rect()
        img_rect.x = x
        img_rect.y = 5
        game.screen.blit(life_img, img_rect)
        x += 50

def draw_text(surface, text, size, color, x, y):
    font = pygame.font.Font((path.join(img_dir, "kenvector_future_thin.ttf")), size)
    text = font.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.midtop = (x, y)
    surface.blit(text, text_rect)

def draw_points(surface, points, color, x, y):
    draw_text(surface, points, 12, color, x, y)
    time.sleep(1)

def draw_player_shield(pct):
    if pct < 0:
        pct = 0
    bar_length = 100
    bar_height = 15
    fill = (pct / 100) * bar_length
    outline_rect = pygame.Rect(5, 5, 100, bar_height)
    fill_rect = pygame.Rect(5, 5, fill, bar_height)
    if pct < 20:
        pygame.draw.rect(game.screen, RED, fill_rect)
    elif pct < 40:
        pygame.draw.rect(game.screen, YELLOW, fill_rect)
    else:
        pygame.draw.rect(game.screen, GREEN, fill_rect)
    pygame.draw.rect(game.screen, WHITE, outline_rect, 3)
    draw_text(game.screen, (str(int(pct/100 * bar_length))) + "%", 16, WHITE, 55, 4)

def update():
    all_sprites.update()


class Game:
    # Initialize game window, etc
    def __init__(self):
        pygame.init()
        pygame.mixer.init()
        pygame.display.set_caption("Shmup!")
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.running = True
        self.score = None
        self.playing = False
        self.player = None
        self.m = None
        self.wait = None

    def spawn_mob(self, num):
        for x in range(num):
            self.m = Mob()
            mobs.add(self.m)
            all_sprites.add(self.m)

    # Start New Game
    def new_game(self):
        self.score = 0
        self.player = Player()
        all_sprites.add(self.player)
        all_sprites.add(bullets)
        self.spawn_mob(8)
        self.run()

    # Game Loop
    def run(self):
        self.playing = True
        while self.playing:
            self.clock.tick(FPS)
            self.events()
            update()
            self.draw()

    # Game Loop - Events
    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                if self.playing:
                    self.playing = False
                    game.start_screen()

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_ESCAPE:
                    if self.playing:
                        self.playing = False
                        game.start_screen()

        # Check if a mob hits the player
        hits = pygame.sprite.spritecollide(self.player, mobs, True, pygame.sprite.collide_circle)
        if hits:
            self.wait = pygame.time.get_ticks()

            for hit in hits:
                e = Explotion(hit.rect.center, 'sm')
                all_sprites.add(e)
                self.player.shield -= int(hit.radius * 0.75)
                print(str(int(hit.radius * 0.75)))
                self.spawn_mob(1)


                if self.player.shield <= 0 and self.player.lives != 0:
                    death_explotion = Explotion(self.player.rect.center, 'lg')
                    all_sprites.add(death_explotion)
                    self.player.hide()
                    self.player.lives -= 1
                    self.player.shield = 100
        elif self.player.lives == 0:
            death_explotion = Explotion(self.player.rect.center, 'lg')
            all_sprites.add(death_explotion)
            self.player.kill()

            if pygame.time.get_ticks() - self.wait >= 1000:
                self.playing = False
                self.game_over_screen(self.score)

        # Check if a bullet hits a mob
        hits = pygame.sprite.groupcollide(bullets, mobs, True, True, pygame.sprite.collide_circle)
        if hits:
            for hit in hits:
                self.e = Explotion(hit.rect.center, 'lg')
                all_sprites.add(self.e)
            #print("mob radius =", self.m.radius, ", points =", (50 - self.m.radius))
            self.score += (50 - self.m.radius)
            for i in range(1):
                self.m = Mob()
                all_sprites.add(self.m)
                mobs.add(self.m)

    # Game Loop - Draw
    def draw(self):
        self.screen.blit(background, background_rect)
        draw_lives(self.player.lives)
        draw_text(self.screen, str(game.score), 32, WHITE, WIDTH/2, 10)
        draw_player_shield(self.player.shield)
        all_sprites.draw(self.screen)
        pygame.display.flip()

    # Start Screen
    def start_screen(self):
        all_sprites.empty()
        mobs.empty()
        bullets.empty()

        self.screen.blit(background, background_rect)
        draw_text(self.screen, "Shmup!", 64, WHITE, WIDTH / 2, HEIGHT / 4)
        draw_text(self.screen, "Arrow keys to move, space to fire", 22, WHITE, WIDTH / 2, HEIGHT / 2)
        draw_text(self.screen, "press a key to begin or scape to exit", 18, WHITE, WIDTH / 2, HEIGHT * 3 / 4)
        waiting = True
        pygame.display.flip()
        while waiting:
            self.clock.tick(FPS)
            check_new_game()

    # Game Over/Continue
    def game_over_screen(self, score):
        self.wait = pygame.time.get_ticks()
        self.screen.blit(background, background_rect)
        draw_text(self.screen, "GAME OVER", 64, WHITE, WIDTH / 2, HEIGHT / 4)
        draw_text(self.screen, "Your Score: " + str(score), 32, WHITE, WIDTH / 2, HEIGHT / 2)
        pygame.display.flip()

        waiting = True
        while waiting:
            self.clock.tick(FPS)
            if pygame.time.get_ticks() - self.wait >= 2000:
                self.start_screen()
            check_new_game()


game = Game()
game.start_screen()
